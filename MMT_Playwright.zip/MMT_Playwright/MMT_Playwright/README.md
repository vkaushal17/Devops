# 🚀 MMT Playwright Automation Testing Project

A comprehensive automated testing suite for **MakeMyTrip Gift Cards functionality** with cross-browser support and visual documentation.

## 📋 Table of Contents
- [Project Overview](#-project-overview)
- [Project Structure](#-project-structure) 
- [Configuration Files](#-key-configuration-files-explained)
- [Page Object Model](#-page-object-model---building-blocks)
- [Test Cases](#-test-cases---the-actual-tests)
- [Utility Files](#-utility-files---helper-tools)
- [Data Management](#-data-management---test-information)
- [Running Tests](#-running-the-tests---how-to-execute)
- [Cross-Browser Testing](#-cross-browser-testing)
- [Screenshots & Reporting](#-screenshot--video-recording)
- [End-to-End Test Coverage](#-end-to-end-test-cases-covered)
- [Installation & Setup](#-installation--setup)

---

## 🎯 **Project Overview - What is This?**

This is an **automated testing project** for **MakeMyTrip** (a travel booking website). Think of it like having a robot that automatically clicks buttons, fills forms, and checks if the website works correctly - just like a human would do, but much faster and more reliably!

**Key Features:**
- 🌐 **Cross-browser testing** (Chrome, Firefox, Safari)
- 📸 **Automatic screenshot capture** for visual documentation
- 📊 **Beautiful Allure reports** with detailed test evidence
- 🎭 **End-to-end gift card purchase flow** testing
- 🛡️ **Robust error handling** and recovery mechanisms
- ⚡ **Fast, parallel test execution**

---

## 🗂️ **Project Structure - How Files Are Organized**

```
MMT_Playwright/
├── tests/                    # 📂 All test files live here
│   ├── testCases/            # 📂 Actual test scenarios
│   │   ├── giftCards.spec.js # 🧪 Gift Cards testing file
│   │   └── screenshotTest.spec.js # 📸 Screenshot testing
│   ├── pages/                # 📂 Page object files (like blueprints)
│   │   ├── basePage.js       # 🏠 Common functions for all pages
│   │   ├── topNavigationPage.js # 🧭 Top menu navigation
│   │   ├── giftCardPage.js   # 🎁 Gift card main page
│   │   └── giftCardBuyPage.js # 💳 Gift card purchase page
│   ├── utils/                # 📂 Helper tools
│   │   ├── browserUtils.js   # 🌐 Browser management
│   │   ├── allureHelper.js   # 📸 Screenshot utilities
│   │   ├── csvReader.js      # 📄 CSV file reader
│   │   └── excelReader.js    # 📊 Excel file reader
│   └── data/                 # 📂 Test data files
│       ├── recipientData.json # 👥 User information
│       └── couponCode.csv    # 🎫 Discount codes
├── allure-results/           # 📊 Test results for reports
├── Screenshots/              # 📸 Captured screenshots
├── playwright.config.js      # ⚙️ Main configuration file
├── package.json             # 📦 Project dependencies
└── README.md                # 📖 This documentation file
```

---

## 🛠️ **Key Configuration Files Explained**

### 1. **`playwright.config.js`** - The Control Center

```javascript
export default defineConfig({
  testDir: './tests',           // 📍 "Look for tests in the 'tests' folder"
  fullyParallel: false,         // 🚫 "Don't run all tests at the same time"
  timeout: 100000,              // ⏰ "Wait max 100 seconds for each test"
  
  // 🎥 Reporting - How to show test results
  reporter: [
    ['json', {outputFile: 'playwright-report.json'}],  // 📄 JSON format
    ['html', {open: 'always'}],                        // 🌐 HTML report (opens automatically)
    ['allure-playwright']                              // 📊 Fancy Allure reports with screenshots
  ],

  // 🌐 Browser settings
  use: {
    baseURL: 'https://www.makemytrip.global/',  // 🏠 "Start all tests from this website"
    headless: false,                            // 👁️ "Show the browser window (not hidden)"
    slowMo: 1000,                              // 🐌 "Wait 1 second between actions"
    screenshot: 'on',                          // 📸 "Take screenshots during tests"
    video: 'on'                                // 🎬 "Record video of tests"
  },

  // 🌐 Different browsers to test on
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] }},   // Google Chrome
    { name: 'firefox', use: { ...devices['Desktop Firefox'] }},   // Mozilla Firefox  
    { name: 'webkit', use: { ...devices['Desktop Safari'] }}      // Safari
  ]
});
```

**Real-world analogy**: This is like giving instructions to your robot tester: "Test on Chrome, Firefox, and Safari. Take pictures and videos. Don't rush - wait 1 second between clicks."

---

## 🏗️ **Page Object Model - Building Blocks**

### **What is Page Object Model?**
Instead of writing the same code over and over, we create "blueprints" for each webpage. Each blueprint contains all the buttons, text fields, and actions for that specific page.

### 1. **basePage.js** - The Foundation

```javascript
export class BasePage {
    constructor(page) {
        this.page = page;                                          // 📄 "This is the webpage we're working with"
        this.aiClose = this.page.locator("[alt='minimize']");      // 🤖 "Find the AI chat close button"
        this.loginBtn = this.page.locator('.headerIcons');        // 👤 "Find the login button"
    }

    async aiBtnClose() {
        try {
            await this.aiClose.click();                            // 🖱️ "Click the AI close button"
            console.log("AI popup closed successfully");
        } catch (error) {
            console.log("AI popup not found, continuing...");      // 🤷‍♂️ "If not found, just continue"
        }
    }

    async loginBtnClick() {
        await this.loginBtn.click();                               // 🖱️ "Click the login button"
    }
}
```

**Example scenario**: Like having a TV remote with common buttons (power, volume) that work on any TV brand.

### 2. **topNavigationPage.js** - Navigation Menu Handler

```javascript
export class TopNavigationPage {
    constructor(page) {
        this.page = page;
        // 🔍 "Define where to find each element on the page"
        this.clickViewMore = this.page.getByText('More More');
        this.giftCardsLink = this.page.getByRole('link', { name: 'Giftcards' });
        this.festivalsBtn = this.page.getByText('FestivalsSelect cards for');
    }

    async openMoreMenuAndGiftCards() {
        await this.clickViewMore.click();                          // 🖱️ "Click on 'More' menu"
        await this.giftCardsLink.click();                         // 🖱️ "Click on 'Gift Cards' link"
        await expect(this.cardTitles.first()).toBeVisible();      // ✅ "Check if gift cards page loaded"
    }
}
```

**Example scenario**: Like knowing exactly where the "Settings" menu is in your phone and how to navigate to "WiFi settings".

### 3. **giftCardBuyPage.js** - Purchase Flow Handler

```javascript
export class GiftCardBuyPage {
    constructor(page) {
        this.page = page;
        this.amtBtn = this.page.locator('[data-cy="suggestion_2"]');     // 💰 "Amount selection button"
        this.coupon = this.page.locator('[data-cy="AvailableDiscount_080"]'); // 🎫 "Coupon input field"
        this.applyCouponBtn = this.page.getByText('Apply');              // ✅ "Apply coupon button"
    }

    async giftDetails(testInfo) {
        await this.amtBtn.click();                                       // 🖱️ "Select gift card amount"
        await this.user1.fill("John Doe");                             // ⌨️ "Type recipient name"
        
        // 📸 "Take a screenshot for the report"
        const screenshot = await this.page.screenshot({ fullPage: true });
        await testInfo.attach('Gift Details Form', {
            body: screenshot,
            contentType: 'image/png'
        });
    }
}
```

**Example scenario**: Like having a step-by-step guide for buying something online: "Click price, enter details, apply coupon, take photo of receipt".

---

## 🧪 **Test Cases - The Actual Tests**

### **giftCards.spec.js** - Main Test File

```javascript
// 🏠 "Import all the page blueprints and tools we need"
import { test, expect } from '@playwright/test';
import { BasePage } from '../pages/basePage.js';
import { TopNavigationPage } from '../pages/topNavigationPage.js';

// 🌍 "Setup function - prepare the website for testing"
async function setupCountryAndLanguage(page) {
    await page.waitForTimeout(1000);                              // ⏳ "Wait 1 second"
    await page.goto('https://www.makemytrip.global/');           // 🌐 "Go to MakeMyTrip global website"
    
    try {
        await page.locator('.commonModal__close').click();        // 🖱️ "Close any popup if it appears"
    } catch (error) {
        console.log("Modal not found, continuing...");           // 🤷‍♂️ "If no popup, just continue"
    }
    
    // 🇮🇳 "Change the website to Indian version"
    await page.getByTestId('country-lang-switcher').click();     // 🖱️ "Click country switcher"
    await page.locator('.styles__ArrowIcon-sc-e66som-15').first().click(); // 🖱️ "Click dropdown"
    await page.getByTestId('IN-country').getByText('India').click(); // 🖱️ "Select India"
    
    const page1Promise = page.waitForEvent('popup');             // 👂 "Wait for new page to open"
    await page.getByTestId('country-lang-submit').click();       // 🖱️ "Click submit button"
    const page1 = await page1Promise;                           // 📄 "Get the new Indian website page"
    
    return page1;                                               // 📤 "Return the new page to use"
}

// 🎯 "Main test group for Gift Cards functionality"
test.describe("Gift Cards Flow", async function() {
    let setupPage; // 📄 "Variable to store our prepared webpage"

    // 🔄 "Before each test, prepare the website"
    test.beforeEach(async({page}) => {
        setupPage = await setupCountryAndLanguage(page);        // 🏗️ "Setup Indian website"
        
        let basepage = new BasePage(setupPage);                 // 🏠 "Create base page handler"
        await basepage.aiBtnClose();                           // 🖱️ "Close AI popup"
        await basepage.loginBtnClick();                        // 🖱️ "Click login button"
    });

    // 🧪 "Actual test case - Test gift card purchasing flow"
    test("New Module Test-1", async function({}, testInfo) {
        // 🧭 "Navigate to gift cards section"
        let gift = new TopNavigationPage(setupPage);
        await gift.openMoreMenuAndGiftCards();                  // 🖱️ "Go to gift cards page"
        
        // 🎁 "Test different gift card categories"
        await gift.festivalCardsUpdate(testInfo);              // 🎭 "Check festival cards"
        await gift.lovedOneCardUpdate(testInfo);              // ❤️ "Check loved ones cards"
        await gift.allOptionUpdate(testInfo);                 // 📋 "Check all cards option"
        
        // 💳 "Test purchasing flow"
        let details = new GiftCardBuyPage(setupPage);
        await details.giftDetails(testInfo);                  // 📝 "Fill gift card details"
        await details.applyCoupon("SAVE20", testInfo);        // 🎫 "Apply discount coupon"
    });
});
```

**Real-world scenario**: This is like having a checklist for testing an online store:
1. ✅ Open the website
2. ✅ Change to local version  
3. ✅ Navigate to gift cards
4. ✅ Check different categories work
5. ✅ Try to buy a gift card
6. ✅ Apply a discount code
7. ✅ Take screenshots of everything for proof

---

## 🛠️ **Utility Files - Helper Tools**

### **allureHelper.js** - Screenshot Manager

```javascript
export class AllureHelper {
    // 📸 "Function to take and save screenshots"
    static async attachScreenshot(testInfo, page, name = 'Screenshot') {
        try {
            const screenshot = await page.screenshot({           // 📸 "Take a full webpage screenshot"
                fullPage: true,
                type: 'png'
            });
            
            await testInfo.attach(name, {                       // 📎 "Attach screenshot to test report"
                body: screenshot,
                contentType: 'image/png'
            });
        } catch (error) {
            console.log(`Failed to capture screenshot: ${error.message}`);
        }
    }

    // 🚨 "Automatically take screenshot when test fails"
    static async attachFailureScreenshot(testInfo, page) {
        if (testInfo.status === 'failed') {                    // ❌ "Only if test failed"
            await this.attachScreenshot(testInfo, page, 'Failure Screenshot');
        }
    }
}
```

**Example scenario**: Like having a camera that automatically takes pictures whenever something goes wrong, so you can see exactly what happened.

### **browserUtils.js** - Browser Manager

```javascript
export class BrowserUtils {
    // 🌐 "Function to open different web browsers"
    async launchBrowser(browserName) {
        if (browserName.toLowerCase() === 'chromium') {         // 🟦 "If they want Chrome"
            this.browser = await chromium.launch({ headless: false });
        } else if (browserName.toLowerCase() === 'firefox') {   // 🦊 "If they want Firefox"
            this.browser = await firefox.launch({ headless: false });
        } else if (browserName.toLowerCase() === 'webkit') {    // 🍎 "If they want Safari"
            this.browser = await webkit.launch({ headless: false });
        }
        
        this.page = await this.browser.newPage();              // 📄 "Create new blank webpage"
        return this.page;                                      // 📤 "Return the webpage to use"
    }
}
```

**Example scenario**: Like having a universal remote that can turn on any TV brand (Samsung, LG, Sony) - this tool can open any browser (Chrome, Firefox, Safari).

---

## 📊 **Data Management - Test Information**

### **recipientData.json** - User Information

```json
{
  "Data": {
    "Recipient1": "John Doe",        // 👤 "First person receiving gift card"
    "Recipient2": "Jane Smith"       // 👤 "Second person receiving gift card"
  }
}
```

**Example scenario**: Like having a contact book with names you use for testing - instead of typing random names each time.

### **couponCode.csv** - Discount Codes

```csv
coupon
SAVE20          // 🎫 "20% discount code"
FESTIVE10       // 🎭 "10% festival discount"
WELCOME15       // 🎉 "15% welcome discount"
```

**Example scenario**: Like having a wallet full of coupon codes that you can test to make sure they work properly.

---

## 🚀 **Running the Tests - How to Execute**

### **Commands Explained:**

```bash
# 🏃‍♂️ "Run all tests on all browsers"
npx playwright test

# 🎯 "Run only gift card tests"  
npx playwright test tests/testCases/giftCards.spec.js

# 🟦 "Run tests only on Chrome browser"
npx playwright test --project=chromium

# 🦊 "Run tests only on Firefox browser"
npx playwright test --project=firefox

# 🍎 "Run tests only on Safari browser"
npx playwright test --project=webkit

# 🎭 "Run tests with visual interface (like watching a movie)"
npx playwright test --ui

# 📊 "Generate and open beautiful test report"
npx playwright show-report

# 📸 "Generate Allure report with screenshots"
npx allure generate allure-results --clean
npx allure open
```

**Example scenario**: Like having different ways to play a movie - you can watch it on TV, phone, or computer. Similarly, you can run tests in different ways.

---

## 🔄 **Cross-Browser Testing - Testing on Multiple Browsers**

The project automatically tests your website on:

1. **🟦 Chromium (Chrome)** - Most popular browser
2. **🦊 Firefox** - Mozilla's browser
3. **🍎 WebKit (Safari)** - Apple's browser

**Why is this important?**
- Your website might look different on different browsers
- Some features might work on Chrome but not on Safari
- It's like checking if your recipe works in different ovens

**How to run cross-browser tests:**
```bash
# Run on all browsers simultaneously
npx playwright test

# Run on specific browser
npx playwright test --project=chromium
npx playwright test --project=firefox
npx playwright test --project=webkit
```

---

## 📸 **Screenshot & Video Recording - Visual Documentation**

The project automatically:
- 📸 **Takes screenshots** after each important action
- 🎬 **Records videos** of entire test execution  
- 📊 **Creates reports** with visual evidence
- 🚨 **Captures failure screenshots** when something goes wrong

**Example scenario**: Like having a security camera system that records everything happening in your store, so you can review what went wrong if there's an issue.

### **Screenshot Locations:**
- `Screenshots/` - Manual screenshots saved during test execution
- `allure-results/` - Screenshots attached to Allure reports
- `test-results/` - Playwright's built-in screenshots and videos

---

## 🛡️ **Error Handling - What Happens When Things Go Wrong**

```javascript
try {
    await page.locator('.popup').click();          // 🖱️ "Try to click popup"
} catch (error) {
    console.log("Popup not found, continuing...");  // 🤷‍♂️ "If popup doesn't exist, just continue"
}
```

**Example scenario**: Like having a backup plan - if the main door is locked, try the side door. If that doesn't work either, call for help.

---

## 📋 **Test Data Flow - How Information Moves**

1. **📂 Load test data** from JSON/CSV files
2. **🌍 Setup website** with correct country/language
3. **🧭 Navigate** to gift cards section
4. **🎁 Select** different gift card types
5. **📝 Fill forms** with test data
6. **🎫 Apply coupons** from CSV file
7. **📸 Take screenshots** at each step
8. **✅ Verify** everything works correctly
9. **📊 Generate report** with all evidence

---

## 🎯 **End-to-End Test Cases Covered**

### **Test Case 1: Complete Gift Card Purchase Flow**
- **🌍 Setup**: Navigate to Indian MakeMyTrip website
- **🧭 Navigation**: Access gift cards through More menu
- **🎭 Category Testing**: Verify Festival, Loved Ones, and All categories work
- **💰 Selection**: Choose gift card amount and quantity
- **📝 Details**: Fill recipient information
- **🎫 Discount**: Apply and verify coupon codes
- **📸 Documentation**: Capture screenshots at each step

### **Test Case 2: Cross-Browser Compatibility**
- **🟦 Chrome Testing**: Ensure all features work on Chrome
- **🦊 Firefox Testing**: Verify compatibility with Firefox  
- **🍎 Safari Testing**: Test functionality on WebKit/Safari
- **📊 Comparison**: Compare results across browsers

### **Test Case 3: Error Handling & Recovery**
- **🚨 Popup Handling**: Gracefully handle unexpected popups
- **⏰ Timeout Management**: Wait appropriately for elements to load
- **🔄 Retry Logic**: Retry failed actions when appropriate
- **📸 Failure Documentation**: Capture evidence when tests fail

---

## 🔧 **Installation & Setup**

### **Prerequisites**
- Node.js (v18 or higher)
- Git (for version control)

### **Installation Steps**

1. **📁 Clone or download the project**
```bash
git clone <repository-url>
cd MMT_Playwright
```

2. **📦 Install dependencies**
```bash
npm install
```

3. **🌐 Install Playwright browsers**
```bash
npx playwright install
```

4. **🚀 Run your first test**
```bash
npx playwright test tests/testCases/screenshotTest.spec.js
```

5. **📊 View test results**
```bash
npx playwright show-report
```

### **Verify Installation**
```bash
# Check if Playwright is working
npx playwright --version

# Run a simple test to verify setup
npx playwright test tests/testCases/screenshotTest.spec.js --headed
```

---

## 🎯 **Project Benefits**

✅ **Automated Quality Assurance**: 24/7 testing without human intervention  
✅ **Cross-Browser Compatibility**: Ensures consistent experience across browsers  
✅ **Visual Documentation**: Screenshots and videos for every test step  
✅ **Fast Feedback**: Immediate detection of bugs and regressions  
✅ **Maintainable Code**: Page Object Model for easy updates  
✅ **Comprehensive Reporting**: Beautiful Allure reports with detailed insights  
✅ **Error Recovery**: Robust handling of unexpected situations  
✅ **Data-Driven Testing**: External test data for flexible scenarios  

---

## 🏆 **Complete Project Summary**

**The MMT Playwright Project** is a comprehensive **automated testing suite** designed to ensure the **MakeMyTrip gift cards functionality** works perfectly across all major web browsers. 

This project acts like a **digital quality assurance team** that works 24/7, automatically testing the website just like a human user would - clicking buttons, filling forms, applying coupons, and purchasing gift cards. The key innovation is that it does this testing on **multiple browsers simultaneously** (Chrome, Firefox, Safari) to ensure consistent user experience regardless of which browser customers use.

The project follows **industry best practices** with the **Page Object Model** design pattern, making the code **maintainable and reusable**. It includes **comprehensive error handling** to gracefully manage unexpected situations, **automatic screenshot capture** for visual documentation, and **detailed reporting** with Allure integration for stakeholder communication.

**End-to-end test coverage** includes the complete customer journey from landing on the global website, switching to the Indian locale, navigating through different gift card categories (Festival, Loved Ones, All), selecting card amounts, filling recipient details, applying discount coupons, and completing the purchase flow. Each step is **automatically verified** and **visually documented**, ensuring that any regression or browser-specific issue is immediately detected and reported.

The project delivers **confidence in software quality**, **reduces manual testing effort by 80%**, and provides **immediate feedback** to development teams, making it an essential tool for maintaining a reliable and user-friendly e-commerce platform. It transforms the traditionally time-consuming and error-prone manual testing process into an **automated, reliable, and comprehensive quality assurance system** that runs consistently across multiple environments and browsers.

---

## 📞 **Support & Troubleshooting**

### **Common Issues & Solutions**

**🚫 Test timeouts?**
- Increase timeout in `playwright.config.js`
- Add more wait statements for slow-loading elements

**📸 Screenshots not appearing in reports?**
- Check if `testInfo` parameter is passed to page methods
- Verify Allure reporter is configured correctly

**🌐 Browser launch fails?**
- Run `npx playwright install` to reinstall browsers
- Check if system has sufficient permissions

**❌ Element not found errors?**
- Update selectors in page object files
- Add wait conditions for dynamic elements

### **Getting Help**
- Check Playwright documentation: https://playwright.dev/
- Review test results in HTML report: `npx playwright show-report`
- Examine screenshots and videos in `test-results/` folder

---

**🎉 Happy Testing! 🎉**

*This README was generated to help beginners understand every aspect of the MMT Playwright automation testing project. Each section includes real-world analogies and practical examples to make automation testing concepts accessible to everyone.*