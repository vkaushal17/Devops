import { expect } from '@playwright/test';

export class AllureHelper {
    
    /**
     * Attach a screenshot to Allure report
     * @param {Object} testInfo - Playwright testInfo object
     * @param {Object} page - Playwright page object  
     * @param {string} name - Name for the attachment
     * @param {boolean} fullPage - Whether to capture full page (default: true)
     */
    static async attachScreenshot(testInfo, page, name, fullPage = true) {
        try {
            const screenshot = await page.screenshot({ 
                fullPage: fullPage,
                type: 'png'
            });

            await testInfo.attach(name, {
                body: screenshot,
                contentType: 'image/png'
            });
            
            console.log(`Screenshot attached: ${name}`);
        } catch (error) {
            console.error(`Failed to attach screenshot ${name}:`, error);
        }
    }

    /**
     * Attach a step screenshot with automatic naming
     * @param {Object} testInfo - Playwright testInfo object
     * @param {Object} page - Playwright page object
     * @param {string} stepName - Name of the test step
     */
    static async attachStepScreenshot(testInfo, page, stepName) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        await this.attachScreenshot(testInfo, page, `${stepName} - ${timestamp}`);
    }

    /**
     * Attach text content to Allure report
     * @param {Object} testInfo - Playwright testInfo object
     * @param {string} name - Name for the attachment
     * @param {string} content - Text content to attach
     */
    static async attachText(testInfo, name, content) {
        await testInfo.attach(name, {
            body: content,
            contentType: 'text/plain'
        });
    }

    /**
     * Attach JSON data to Allure report
     * @param {Object} testInfo - Playwright testInfo object
     * @param {string} name - Name for the attachment
     * @param {Object} data - JSON data to attach
     */
    static async attachJSON(testInfo, name, data) {
        await testInfo.attach(name, {
            body: JSON.stringify(data, null, 2),
            contentType: 'application/json'
        });
    }

    /**
     * Attach HTML content to Allure report
     * @param {Object} testInfo - Playwright testInfo object
     * @param {string} name - Name for the attachment
     * @param {string} html - HTML content to attach
     */
    static async attachHTML(testInfo, name, html) {
        await testInfo.attach(name, {
            body: html,
            contentType: 'text/html'
        });
    }

    /**
     * Attach page source HTML to Allure report
     * @param {Object} testInfo - Playwright testInfo object
     * @param {Object} page - Playwright page object
     * @param {string} name - Name for the attachment (optional)
     */
    static async attachPageSource(testInfo, page, name = 'Page Source') {
        const html = await page.content();
        await this.attachHTML(testInfo, name, html);
    }

    /**
     * Take and attach screenshot on failure
     * @param {Object} testInfo - Playwright testInfo object
     * @param {Object} page - Playwright page object
     */
    static async attachFailureScreenshot(testInfo, page) {
        if (testInfo.status === 'failed') {
            await this.attachScreenshot(testInfo, page, 'Failure Screenshot');
            await this.attachPageSource(testInfo, page, 'Failure Page Source');
        }
    }
}