import XLSX from "xlsx"

export function readData(fileName, sheetName) 
{
     const excelFile = 
     XLSX.readFile(`C:\Users\\\mkaushal\\Desktop\\MMT_Playwright\\tests\\data\\${fileName}`)
     
     const excelSheet = excelFile.Sheets[sheetName]

     const loginJsonData = XLSX.utils.sheet_to_json(excelSheet)

     return loginJsonData

}