import FS from "fs"
import path from 'path'
import { parse } from "csv-parse/sync"
export function readCsvData()
{
    const csvFile = FS.readFileSync("tests\\data\\couponCode.csv")
    const csvDataObj = parse(csvFile, { columns: true, skip_empty_lines: true }) 
    return csvDataObj


}