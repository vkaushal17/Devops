import { BasePage } from "../pages/BasePage.js"
import {Data} from "../data/recipientData.json"
import {test} from "@playwright/test"
import { TopNavigationPage } from "../pages/topNavigationPage.js"
import { GiftCardPage } from "../pages/giftCardPage.js"
import { GiftCardBuyPage } from "../pages/giftCardBuyPage.js"
import { BrowserUtils } from "../utils/browserUtils.js"
import path from 'path';
import {readCsvData} from "../utils/csvReader.js"

// Setup function for country/language configuration
async function setupCountryAndLanguage(page) {
  await page.waitForTimeout(1000);
  await page.goto('https://www.makemytrip.global/');
  
  try {
    await page.waitForTimeout(1000);
    await page.locator('.commonModal__close').click();
  } catch (error) {
    console.log("Modal close button not found, continuing...");
  }
  
  await page.waitForTimeout(1000);
  await page.getByTestId('country-lang-switcher').click();
  await page.waitForTimeout(1000);
  await page.locator('.styles__ArrowIcon-sc-e66som-15').first().click();
  await page.waitForTimeout(1000);
  await page.getByTestId('IN-country').getByText('India').click();
  
  // Handle popup and wait for navigation
  const page1Promise = page.waitForEvent('popup');
  await page.waitForTimeout(1000);
  await page.getByTestId('country-lang-submit').click();
  const page1 = await page1Promise;
  
  // Wait for the new page to load and return it
  await page1.waitForLoadState();
  return page1;
}

// Cross-browser testing with BrowserUtils
const browserNames = ["chromium", "webkit", "firefox"];

for (let browserName of browserNames) {
  test.describe(`Gift Cards Flow - ${browserName}`, async function() {
    let browserUtils;
    let page;

    test.beforeAll(async () => {
      browserUtils = new BrowserUtils();
      page = await browserUtils.launchBrowser(browserName);
    });

    test.afterAll(async () => {
      await browserUtils.closeBrowser();
    });

    test.beforeEach(async () => {
      // Setup country and language configuration first
      const page1 = await setupCountryAndLanguage(page);
      
      // Continue with existing setup on the returned page1
      let basepage = new BasePage(page1);
      await basepage.aiBtnClose();
      await basepage.loginBtnClick();
      
      // Update page reference for tests
      page = page1;
    });

    test(`New Module Test-1 on ${browserName}`, async function() {
      let gift = new TopNavigationPage(page);
      await gift.openMoreMenuAndGiftCards();
      await gift.festivalCardsUpdate();
      await gift.lovedOneCardUpdate();
      await gift.allOptionUpdate();
      let banner = new GiftCardPage(page);
      await banner.GiftBanner();

      const csvPath = path.join(__dirname, '../data/couponCode.csv');
      const couponData = readCsvData(csvPath);
      const couponCode = couponData[0].coupon;
      let details = new GiftCardBuyPage(page);
      await details.giftDetails();
      await details.applyCoupon(couponCode);
    });

    test(`Test-3 on ${browserName}`, async function() {
      let gift = new TopNavigationPage(page);
      await gift.openMoreMenuAndGiftCards();
      await gift.festivalCardsUpdate();
      await gift.lovedOneCardUpdate();
      await gift.allOptionUpdate();
    });

    test(`Test-4 on ${browserName}`, async function() {
      let banner = new GiftCardPage(page);
      await banner.GiftBanner();
    });

    test(`Test-5 on ${browserName}`, async function() {
      const csvPath = path.join(__dirname, '../data/couponCode.csv');
      const couponData = readCsvData(csvPath);
      const couponCode = couponData[0].coupon;
      let details = new GiftCardBuyPage(page);
      await details.giftDetails();
      await details.applyCoupon(couponCode);
    });
  });
}