import { test } from '@playwright/test';
import { AllureHelper } from "../utils/allureHelper.js";

test.describe('Screenshot Test for Allure', () => {
    
    test('Simple Screenshot Test', async ({ page }, testInfo) => {
        
        // Navigate to a page
        await page.goto('https://www.makemytrip.global/');
        
        // Take and attach screenshot
        await AllureHelper.attachStepScreenshot(testInfo, page, 'Home Page Loaded');
        
        // Attach some test data
        await AllureHelper.attachJSON(testInfo, 'Test Data', {
            url: page.url(),
            title: await page.title(),
            timestamp: new Date().toISOString()
        });
        
        // Attach page source
        await AllureHelper.attachPageSource(testInfo, page, 'Home Page Source');
        
        console.log('Screenshot test completed successfully');
    });
    
});