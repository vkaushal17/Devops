import { BasePage } from "../pages/BasePage.js"
// import {readCsvData} from "../utils/csvReader.js"
// import {readData} from "../utils/excelReader.js"

import {Data} from "../data/recipientData.json"
import {test} from "@playwright/test"
import { TopNavigationPage } from "../pages/topNavigationPage.js"
import { GiftCardPage } from "../pages/giftCardPage.js"
import { GiftCardBuyPage } from "../pages/giftCardBuyPage.js"
import { BrowserUtils } from "../utils/browserUtils.js"
import path from 'path';
import {readCsvData} from "../utils/csvReader.js"
import { AllureHelper } from "../utils/allureHelper.js"

// Setup function for country/language configuration
async function setupCountryAndLanguage(page) {
  await page.waitForTimeout(1000);
  await page.goto('https://www.makemytrip.global/');
  
  try {
    await page.waitForTimeout(1000);
    await page.locator('.commonModal__close').click();
  } catch (error) {
    console.log("Modal close button not found, continuing...");
  }
  
  await page.waitForTimeout(1000);
  await page.getByTestId('country-lang-switcher').click();
  await page.waitForTimeout(1000);
  await page.locator('.styles__ArrowIcon-sc-e66som-15').first().click();
  await page.waitForTimeout(1000);
  await page.getByTestId('IN-country').getByText('India').click();
  
  // Handle popup and wait for navigation
  const page1Promise = page.waitForEvent('popup');
  await page.waitForTimeout(1000);
  await page.getByTestId('country-lang-submit').click();
  const page1 = await page1Promise;
  
  // Wait for the new page to load and return it
  await page1.waitForLoadState();
  return page1;
}

// const browserName = ["chromium","webkit","firefox"]
// for(let i of browserName)
// {
//    let page;
//    const utiCall = new BrowserUtils();
//    test.describe(`Positive Testcases on ${i}`,()=>{
//      test.beforeEach(async()=>{
//           page = await utiCall.launchBrowser(i)
// });


test.describe("Gift Cards Flow",async function()
{
     let setupPage; // Store the setup page for use in tests

     test.beforeEach(async({page, baseURL})=>{
     
     // Setup country and language configuration first
     setupPage = await setupCountryAndLanguage(page)
     
     // Continue with existing setup on the returned page1
    // await setupPage.goto(baseURL)
     let basepage = new BasePage(setupPage)
     await basepage.aiBtnClose()
     await basepage.loginBtnClick()
     })

     // Capture screenshot on test failure
     test.afterEach(async ({ page }, testInfo) => {
         if (setupPage) {
             await AllureHelper.attachFailureScreenshot(testInfo, setupPage);
         }
     })

/**
     * =========================================================================================================
     * Testcase: 1
     * Description -- Navigate to hotels page and search with valid city and date (Positive Test)
     * Created By -- Megha Kaushal
     * Reviewed By -- Gujjula Narasimha Reddy
     * Positive Test case : validate
     * =========================================================================================================
**/    

test.only("New Module Test-1",async function({}, testInfo){
   let gift = new TopNavigationPage(setupPage)
   await gift.openMoreMenuAndGiftCards()
   await gift.festivalCardsUpdate(testInfo)
   await gift.lovedOneCardUpdate(testInfo)
   await gift.allOptionUpdate(testInfo)
   let banner = new GiftCardPage(setupPage)
   await banner.GiftBanner()

   const csvPath = path.join(__dirname,'tests\\data\\couponCode.csv')
   const couponData = readCsvData(csvPath);
   const couponCode = couponData[0].coupon;
   let details = new GiftCardBuyPage(setupPage)
   await details.giftDetails(testInfo)
   await details.applyCoupon(couponCode, testInfo)
})

/**
     * =====================================================================================================================================================================
     * Testcase: 2
     * Description -- Verify that after applying the User rating filter, the highest‑rating sort keeps the same hotels and only changes their order. (Positive Test)
     * Created By -- Megha Kaushal
     * Reviewed By -- 
     * Positive Test case : validate
     * ==================================================================================================================================================================
**/
test("Test-3",async function({}, testInfo){
   let gift = new TopNavigationPage(setupPage)
   await gift.openMoreMenuAndGiftCards()
   await gift.festivalCardsUpdate(testInfo)
   await gift.lovedOneCardUpdate(testInfo)
   await gift.allOptionUpdate(testInfo)
})


// /**
//      * =====================================================================================================================================================================
//      * Testcase: 3
//      * Description -- Verify budget filter with boundary values for an invalid budget range (min > max). (Negative Test)
//      * Created By -- Megha Kaushal
//      * Reviewed By -- 
//      * Positive Test case : validate
//      * ==================================================================================================================================================================
// **/

test("Test-4",async function({}, testInfo){
   let banner = new GiftCardPage(setupPage)
   await banner.GiftBanner()
   
   // Take screenshot for this test step
   await AllureHelper.attachStepScreenshot(testInfo, setupPage, "Gift Banner Displayed")
})


// /**
//      * =====================================================================================================================================================================
//      * Testcase: 4
//      * Description -- Verify selecting a room and proceeding to booking with guest details. (Positive Test)
//      * Created By -- Megha Kaushal
//      * Reviewed By -- 
//      * Positive Test case : validate
//      * ==================================================================================================================================================================
// **/

test("Test-5",async function({}, testInfo){
   const csvPath = path.join(__dirname,'tests\\data\\couponCode.csv')
   const couponData = readCsvData(csvPath);
   const couponCode = couponData[0].coupon;
   let details = new GiftCardBuyPage(setupPage)
   await details.giftDetails(testInfo)
   await details.applyCoupon(couponCode, testInfo)
})
   



// })

// test("New Test-5",async function({page}){
//      let category = new TopNavigationPage(page)
//      await category.exploreCategory()
// })


})
