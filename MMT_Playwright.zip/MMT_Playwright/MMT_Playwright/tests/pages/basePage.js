export class BasePage
{
    constructor(page)
    {
        this.page = page;
        this.aiCloseBtn = this.page.locator("[alt='minimize']");
        this.loginCancelBtn = this.page.locator('[data-cy="closeModal"]')
        this.hotelURL= this.page.getByRole('link',{name:'Hotels'})

    }
   
    async aiBtnClose()
    {
        await this.aiCloseBtn.click();
    }

    async loginBtnClick()
    {
        await this.loginCancelBtn.click();
    }

    async navigate()
    {
        await this.hotelURL.click()
    }
}


 
