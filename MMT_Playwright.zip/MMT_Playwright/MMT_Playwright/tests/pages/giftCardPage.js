import { expect} from '@playwright/test';
export class GiftCardPage {
    constructor(page) {
       
        this.page = page;
        this.bookNowBtn = this.page.locator('[data-cy="GiftCardBanner_480"]')
        this.buyBtn = this.page.getByRole('button',{name : "BUY NOW"})

    }

    async GiftBanner(){
    await this.bookNowBtn.click({timeout:3000})
    await expect(this.buyBtn).toBeVisible({ timeout: 10000 })
    await this.page.waitForTimeout(5000)

    }

}

  

//   await page.getByText('Edit Image/Message').click();
//   await page.getByPlaceholder(' ').nth(4).click();
//   await page.locator('.popup__close').click();