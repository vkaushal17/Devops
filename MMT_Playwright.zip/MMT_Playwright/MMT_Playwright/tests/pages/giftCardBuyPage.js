import { expect} from '@playwright/test';
const testData=require("../data/recipientData.json")
export class GiftCardBuyPage {
    constructor(page) {
        this.page = page
        this.amtBtn = this.page.locator('[data-cy="suggestion_2"]')
        this.increaseQuantity = this.page.locator("[data-cy='Counter_443']")
        this.clickSlider = this.page.locator('.slider')
        this.coupon = this.page.locator('[data-cy="AvailableDiscount_080"]')
        this.applyCouponBtn = this.page.getByText('Apply')
        this.user1 = this.page.locator('[data-cy="Recipient_0"]')
        this.user2 = this.page.locator('[data-cy="Recipient_1"]')
        this.aiCloseBtn = this.page.locator("[alt='minimize']");
        
        
}    

async giftDetails(testInfo){

    await expect(this.amtBtn).toBeVisible();
    await this.amtBtn.click()
    await expect(this.increaseQuantity).toBeVisible();
    await this.increaseQuantity.click()
    await expect(this.clickSlider).toBeVisible();
    await this.clickSlider.click()

    const val = testData.Data;
    await expect(this.user1).toBeEditable();
    await this.user1.fill(val.Recipient1)

    await expect(this.user1).toHaveValue("",{ timeout: 10000 })
    await expect(this.user1).toBeEditable();

    await this.user2.fill(val.Recipient2)
    await expect(this.user2).toHaveValue("",{ timeout: 10000 })
    
    // Take screenshot for Allure report
    const screenshot = await this.page.screenshot({ 
        fullPage: true 
    })

    await testInfo.attach('Gift Details Form', {
        body: screenshot,
        contentType: 'image/png'
    })
}

async applyCoupon(couponCode, testInfo){
        await this.aiCloseBtn.click()
        await this.coupon.fill(couponCode)
        await expect(this.coupon).toHaveValue(couponCode);
        await this.applyCouponBtn.click()
        await expect(this.applyCouponBtn).toBeVisible()
        
        // Take screenshot for Allure report
        const screenshot = await this.page.screenshot({ 
            fullPage: true 
        })

        await testInfo.attach('Coupon Applied', {
            body: screenshot,
            contentType: 'image/png'
        })
    }

}