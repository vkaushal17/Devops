import { expect} from '@playwright/test';
export class TopNavigationPage {
    constructor(page) {
       
        this.page = page;
        this.clickViewMore = this.page.getByText('More More')
        this.giftCardsLink = this.page.getByRole('link', { name: 'Giftcards' })
        this.festivalsBtn = this.page.getByText('FestivalsSelect cards for')
        this.lovedOneCardBtn = this.page.getByText('Loved OnesTravel specific')
        this.allBtn = this.page.locator('label').filter({ hasText: 'All' })
        this.firstFestivalCardTitle = this.page.locator('[data-cy="SingleGiftCard_51"]')
        this.firstLovedOneCardTitle =this.page.getByRole('heading', { name: "Luxury Hotels Gift Card" })
        this.firstAllCardTitle = this.page.getByRole('heading', { name: "Wedding Gift Card" })
        this.cardTitles = this.page.getByText("Gift Cards")
   
    }

async openMoreMenuAndGiftCards(){

    //await this.viewMoreClick.scrollIntoViewIfNeeded()
    await this.clickViewMore.click()
    await this.giftCardsLink.click()
    await expect(this.cardTitles.first()).toBeVisible({ timeout: 10000 });
}
async festivalCardsUpdate(testInfo){
    await this.festivalsBtn.click()
    await expect(this.firstFestivalCardTitle).toBeVisible({ timeout: 10000 })
    
    try {
        // Take screenshot for Allure report - simple approach
        const screenshot = await this.page.screenshot({ 
            fullPage: true,
            type: 'png'
        })

        await testInfo.attach('Festival Gift Cards Page', {
            body: screenshot,
            contentType: 'image/png'
        });
        
        console.log('Festival cards screenshot attached successfully');
    } catch (error) {
        console.error('Failed to attach festival cards screenshot:', error);
    }
}
async lovedOneCardUpdate(testInfo){
    await this.lovedOneCardBtn.click()
    await expect(this.firstLovedOneCardTitle).toBeVisible({ timeout: 10000 })
    
    // Take screenshot for Allure report
    const screenshot = await this.page.screenshot({ 
        fullPage: true 
    })

    await testInfo.attach('Loved Ones Gift Cards Page', {
        body: screenshot,
        contentType: 'image/png'
    })
}
async allOptionUpdate(testInfo){
   await this.allBtn.click()
   await expect(this.firstAllCardTitle).toBeVisible({ timeout: 10000 })
   
   // Take screenshot for Allure report
   const screenshot = await this.page.screenshot({ 
       fullPage: true 
   })

   await testInfo.attach('All Gift Cards Page', {
       body: screenshot,
       contentType: 'image/png'
   })
}

}

